from pathlib import Path
P=Path(__file__).parent
s=Path('C:/Users/ADM/Downloads/pozharnik-analytics.js').read_text(encoding='utf-8')
s=s.replace('var VERSION = "2.1";','var VERSION = "2.2";')
s=s.replace('return JSON.parse(value);','var parsed = JSON.parse(value);\n      return parsed == null ? fallback : parsed;')
s=s.replace('var source = queryParameter("utm_source");','if (queryParameter("gclid") || queryParameter("gbraid") || queryParameter("wbraid")) return {source:"google", medium:"cpc"};\n    if (queryParameter("yclid")) return {source:"yandex", medium:"cpc"};\n    var source = queryParameter("utm_source");')
s=s.replace('if (host === window.location.hostname)','if (normalizeHost(host) === normalizeHost(window.location.hostname))')
s=s.replace('if (!lastTouch || hasCampaignParameters()) {','var externalEntry = false;\n  if (document.referrer) {\n    try { externalEntry = normalizeHost(new URL(document.referrer).hostname) !== normalizeHost(window.location.hostname); } catch (ignore) {}\n  }\n  if (!lastTouch || hasCampaignParameters() || externalEntry) {')
old='''  var visitCount = parseInt(localGet(VISITS_KEY) || "0", 10) + 1;
  localSet(VISITS_KEY, String(visitCount));

  var sessionId = sessionGet(SESSION_KEY) || uuid();
  var sessionStartedAt = sessionGet(SESSION_START_KEY) || new Date().toISOString();
  sessionSet(SESSION_KEY, sessionId);
  sessionSet(SESSION_START_KEY, sessionStartedAt);'''
new='''  var ACTIVITY_KEY = PREFIX + "session_last_activity";
  var existingSession = sessionGet(SESSION_KEY);
  var lastActivity = Number(sessionGet(ACTIVITY_KEY) || 0);
  var newSession = !existingSession || !lastActivity || Date.now() - lastActivity > 30 * 60 * 1000;
  var sessionId = newSession ? uuid() : existingSession;
  var sessionStartedAt = newSession ? new Date().toISOString() : sessionGet(SESSION_START_KEY) || new Date().toISOString();
  var visitCount = parseInt(localGet(VISITS_KEY) || "0", 10) + (newSession ? 1 : 0);
  if (!Number.isFinite(visitCount) || visitCount < 1) visitCount = 1;
  localSet(VISITS_KEY, String(visitCount));
  sessionSet(SESSION_KEY, sessionId);
  sessionSet(SESSION_START_KEY, sessionStartedAt);
  if (newSession) sessionSet(ACTIVITY_KEY, String(Date.now()));
  function recordActivity() {
    var previous = Number(sessionGet(ACTIVITY_KEY) || 0);
    if (previous && Date.now() - previous > 30 * 60 * 1000) {
      sessionId = uuid(); sessionStartedAt = new Date().toISOString();
      visitCount = parseInt(localGet(VISITS_KEY) || "0", 10) + 1;
      if (!Number.isFinite(visitCount)) visitCount = 1;
      localSet(VISITS_KEY, String(visitCount));
      sessionSet(SESSION_KEY, sessionId); sessionSet(SESSION_START_KEY, sessionStartedAt);
    }
    sessionSet(ACTIVITY_KEY, String(Date.now()));
  }
  recordActivity();
  ["click", "keydown", "scroll"].forEach(function(type) { document.addEventListener(type, recordActivity, {passive:true}); });'''
assert old in s
s=s.replace(old,new)
for key in ['gclid','gbraid','wbraid','yclid']:
 s=s.replace(f'{key}: lastTouch.{key} || firstTouch.{key} || "",',f'{key}: lastTouch.{key} || "",')
s=s.replace('return safeParse(sessionGet(CTA_KEY), {});','var cta = safeParse(sessionGet(CTA_KEY), {});\n    if (cta.captured_at && Date.now() - Date.parse(cta.captured_at) > 30 * 60 * 1000) return {};\n    return cta;')
s=s.replace('if (!element) return;','if (!element) return;\n      if (element.matches("[type=submit], [data-close], summary")) return;\n      if (element.tagName === "BUTTON" && !element.hasAttribute("data-analytics-location")) return;')
s=s.replace('var form = event.target;\n    dataLayerPush({','var form = event.target;\n    if (!form || typeof form.querySelector !== "function") return;\n    dataLayerPush({')
s=s.replace('function gaClientId() {','var resolvedGaClientId = "";\n  function gaClientId() {\n    if (resolvedGaClientId) return resolvedGaClientId;')
s=s.replace('window.PozharnikAnalytics = {','function resolveGaClientId() {\n    var cfg = window.PozharnikAnalyticsConfig || window.PozharnikHomeConfig || {};\n    if (window.gtag && cfg.gaMeasurementId) {\n      try { window.gtag("get", cfg.gaMeasurementId, "client_id", function(id) { if (id) resolvedGaClientId = String(id); }); } catch (ignore) {}\n    }\n  }\n  resolveGaClientId();\n  window.setTimeout(resolveGaClientId, 2000);\n  window.PozharnikAnalytics = {')
P.joinpath('04_POZHARNIK_ANALYTICS_2_2.js').write_text(s,encoding='utf-8')
print('Analytics 2.2 prepared; source file unchanged')
